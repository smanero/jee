/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.albite.image;

/**
 *
 * @author albus
 */
public class AlbiteImageException extends Exception {
    public AlbiteImageException() {
        super();
    }

    public AlbiteImageException(final String s) {
        super(s);
    }
}
