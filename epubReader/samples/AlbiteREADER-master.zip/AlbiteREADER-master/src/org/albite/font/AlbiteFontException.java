/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.albite.font;

/**
 *
 * @author albus
 */
public class AlbiteFontException extends Exception {
    public AlbiteFontException() {
        super();
    }

    public AlbiteFontException(final String s) {
        super(s);
    }
}
