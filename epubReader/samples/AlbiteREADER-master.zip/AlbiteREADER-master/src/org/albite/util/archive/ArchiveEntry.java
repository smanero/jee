/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.albite.util.archive;

import javax.microedition.io.InputConnection;

/**
 *
 * @author albus
 */
public interface ArchiveEntry
        extends InputConnection, File {}
