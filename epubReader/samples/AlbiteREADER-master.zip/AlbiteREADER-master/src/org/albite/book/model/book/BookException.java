/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.albite.book.model.book;

/**
 *
 * @author Albus Dumbledore
 */
public class BookException extends Exception {

    public BookException() {
        super();
    }

    public BookException(final String s) {
        super(s);
    }
}
